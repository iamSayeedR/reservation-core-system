package com.hotelediary.reservationcoresystem;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ReservationCoreSystemApplication {

	public static void main(String[] args) {
		SpringApplication.run(ReservationCoreSystemApplication.class, args);
	}

}
