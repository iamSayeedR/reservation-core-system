package com.hotelediary.reservationcoresystem;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ReservationCoreSystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
